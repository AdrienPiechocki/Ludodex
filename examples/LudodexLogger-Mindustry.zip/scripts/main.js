// Ludodex Logger for Mindustry — logs game events in a line format readable by Ludodex "Achievements".
// Every line is written to the game log (last_log.txt, via Log.info) AND appended to
// <data folder>/ludodex.log (persistent across sessions). Point Ludodex at whichever you prefer.

const PERSISTENT_FILE = true;       // also append to ludodex.log in the Mindustry data folder
const LOG_FILE_NAME = "ludodex.log";
const ITEM_MILESTONES = [100, 1000, 4000, 9000, 13000];
const POLL_TICKS = 300;             // item polling interval in frames (~5 s at 60 fps)

function str(x){ return String(x); }

function emit(line){
    try{ Log.info(line); }catch(e){}
    if(PERSISTENT_FILE){
        try{ Vars.dataDirectory.child(LOG_FILE_NAME).writeString(line + "\n", true); }catch(e){}
    }
}

function guard(fn){
    return function(e){
        try{ fn(e); }catch(err){
            try{ Log.err("[LudodexLogger] " + err); }catch(e2){}
        }
    };
}

var hooked = [];
var missing = [];
function on(eventName, fn){
    try{
        var cls = this[eventName];
        if(cls === undefined || cls === null){ missing.push(eventName); return; }  // event absent in this game version
        Events.on(cls, guard(fn));
        hooked.push(eventName);
    }catch(err){ missing.push(eventName); }
}

function mine(team){ return Vars.player != null && team === Vars.player.team(); }
function hostile(team){ return Vars.player != null && team !== Vars.player.team() && team !== Team.derelict; }

function sectorInfo(sector){
    if(sector == null) return "none";
    var id = sector.preset != null ? str(sector.preset.name) : ("sector-" + sector.id);
    return id;
}
function planetOf(sector){
    try{ return sector != null ? str(sector.planet.name) : "none"; }catch(e){ return "none"; }
}
function curSector(){
    try{ return Vars.state.rules.sector; }catch(e){ return null; }
}
function mapName(){
    try{ return Vars.state.map != null ? str(Vars.state.map.name()) : "unknown"; }catch(e){ return "unknown"; }
}

// ---------- session / world ----------
on("WorldLoadEvent", function(e){
    var s = curSector();
    var mode = str(Vars.state.rules.mode());
    emit("GAME STARTED: " + mapName() + " | mode=" + mode + " | campaign=" + Vars.state.isCampaign()
        + " | sector=" + sectorInfo(s) + " | planet=" + planetOf(s));
    if(Vars.state.isCampaign() && s != null){
        emit("SECTOR ENTERED: " + sectorInfo(s) + " | name=" + str(s.name()) + " | planet=" + planetOf(s));
    }
});
on("SaveWriteEvent", function(e){ emit("GAME SAVED: " + mapName()); });
on("SaveLoadEvent", function(e){ emit("GAME LOADED: " + mapName()); });

on("WaveEvent", function(e){
    var s = curSector();
    emit("WAVE REACHED: " + Vars.state.wave + " | mode=" + str(Vars.state.rules.mode())
        + " | sector=" + sectorInfo(s) + " | planet=" + planetOf(s));
});

on("GameOverEvent", function(e){
    var won = mine(e.winner);
    var st = Vars.state.stats;
    var s = curSector();
    emit("GAME OVER: " + (won ? "victory" : "defeat") + " | sector=" + sectorInfo(s) + " | planet=" + planetOf(s)
        + " | wave=" + Vars.state.wave
        + " | enemiesDestroyed=" + st.enemyUnitsDestroyed
        + " | built=" + st.buildingsBuilt
        + " | unitsCreated=" + st.unitsCreated);
});

// ---------- sectors / campaign ----------
on("SectorCaptureEvent", function(e){
    var s = e.sector;
    emit("SECTOR CAPTURED: " + sectorInfo(s) + " | name=" + str(s.name()) + " | planet=" + planetOf(s)
        + " | initial=" + e.initialCapture);
});
on("SectorLoseEvent", function(e){
    emit("SECTOR LOST: " + sectorInfo(e.sector) + " | planet=" + planetOf(e.sector));
});
on("SectorLaunchEvent", function(e){
    emit("SECTOR LAUNCH: " + sectorInfo(e.sector) + " | planet=" + planetOf(e.sector));
});
on("LaunchItemEvent", function(e){
    emit("ITEM LAUNCHED: " + str(e.stack.item.name) + " | amount=" + e.stack.amount);
});

// ---------- research / unlocks ----------
on("ResearchEvent", function(e){
    emit("RESEARCH COMPLETE: " + str(e.content.name) + " | type=" + str(e.content.getContentType()));
});
on("UnlockEvent", function(e){
    var t = str(e.content.getContentType());
    if(t === "item" || t === "liquid"){
        emit("RESOURCE UNLOCKED: " + str(e.content.name) + " | type=" + t);
    }
});

// ---------- construction ----------
on("BlockBuildEndEvent", function(e){
    if(!mine(e.team)) return;
    if(e.breaking){
        emit("BLOCK DECONSTRUCTED: x1");
        return;
    }
    var b = e.tile.block();
    var by = (e.unit != null && e.unit.isPlayer()) ? "player" : "builder";
    emit("BLOCK BUILT: " + str(b.name) + " | by=" + by);
});

on("BlockDestroyEvent", function(e){
    var t = e.tile;
    if(t == null || t.build == null) return;
    var b = t.block();
    var team = t.build.team;
    var line = str(b.name) + " | team=" + str(team.name) + " | ours=" + mine(team);
    emit("BLOCK DESTROYED: " + line);
    if(str(b.name).indexOf("core-") === 0){
        emit("CORE DESTROYED: " + line);
    }
});

// ---------- units ----------
on("UnitCreateEvent", function(e){
    if(!mine(e.unit.team)) return;
    emit("UNIT PRODUCED: " + str(e.unit.type.name)
        + " | factory=" + (e.spawner != null ? str(e.spawner.block.name) : "none"));
});

on("UnitDestroyEvent", function(e){
    var u = e.unit;
    var type = str(u.type.name);
    var team = u.team;
    if(u.isPlayer() && u.getPlayer() === Vars.player){
        emit("PLAYER DIED: " + type);
    }
    if(hostile(team)){
        emit("ENEMY DESTROYED: " + type + " | team=" + str(team.name) + " | boss=" + u.isBoss()
            + " | flying=" + u.isFlying());
    }else if(mine(team)){
        emit("UNIT LOST: " + type);
    }
});

on("UnitDrownEvent", function(e){
    emit("UNIT DROWNED: " + str(e.unit.type.name) + " | ours=" + mine(e.unit.team));
});

on("UnitChangeEvent", function(e){
    if(e.player !== Vars.player || e.unit == null) return;
    emit("PLAYER UNIT: " + str(e.unit.type.name));
});

// ---------- misc ----------
on("SchematicCreateEvent", function(e){ emit("SCHEMATIC CREATED: x1"); });
on("HostEvent", function(e){ emit("MULTIPLAYER HOSTED: x1"); });
on("ClientServerConnectEvent", function(e){ emit("MULTIPLAYER JOINED: x1"); });
on("PlayerJoin", function(e){
    if(e.player !== Vars.player) emit("PLAYER JOINED: " + str(e.player.name));
});

// Internal game triggers (the same ones the base game uses for its Steam achievements).
["thoriumReactorOverheat", "impactPower", "forceProjectorBreak", "acceleratorUse", "tutorialComplete"].forEach(function(name){
    try{
        var trig = Trigger[name];
        if(trig === undefined) return;
        Events.run(trig, function(){ emit("GAME TRIGGER: " + name); });
    }catch(err){}
});

// ---------- item milestones (polling) ----------
var lastMilestone = {};
var tick = 0;
try{
    Events.run(Trigger.update, function(){
        if(++tick % POLL_TICKS !== 0) return;
        try{
            if(!Vars.state.isGame() || Vars.player == null) return;
            if(Vars.state.rules.infiniteResources) return;
            var core = Vars.player.core();
            if(core == null) return;
            Vars.content.items().each(function(item){
                var amt = core.items.get(item);
                var name = str(item.name);
                var last = lastMilestone[name] || 0;
                for(var i = 0; i < ITEM_MILESTONES.length; i++){
                    var m = ITEM_MILESTONES[i];
                    if(amt >= m && last < m){
                        emit("ITEM MILESTONE: " + name + " | amount=" + m);
                        lastMilestone[name] = m;
                    }
                }
            });
        }catch(err){}
    });
}catch(err){}

Events.on(ClientLoadEvent, function(e){
    emit("LUDODEX LOGGER READY: hooked=" + hooked.length + " | missing=" + (missing.length ? missing.join(",") : "none"));
});
