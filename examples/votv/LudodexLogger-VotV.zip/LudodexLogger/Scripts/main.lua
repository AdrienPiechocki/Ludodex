-- Ludodex Logger for Voices of the Void (UE4SS Lua mod) - v1.7 (readable DataTable names + ACHIEVEMENT STATE from save_main)
-- Writes one line per game event to the UE4SS log (print) and appends it to %LOCALAPPDATA%\VotV\ludodex.log,
-- in a format read by the Ludodex "Achievements" module (votv-achievements.yaml).
--
-- IMPORTANT: this mod discovers the game's Blueprint functions at runtime instead of hardcoding their names.
-- After your first session, open ludodex-discovery.txt (same folder as ludodex.log) to check what was found
-- and edit CFG below if needed.

local CFG = {
    -- v1.1: nothing but the ClientRestart hook is registered at game startup. Everything else starts
    -- FEATURE_DELAY_MS after the first world load. Switch features off here to bisect a crash.
    ENABLE_POLLING    = true,          -- DAY REACHED / POINTS MILESTONE
    ENABLE_DISCOVERY  = true,          -- scan + hook achievement/advancement/day functions
    TRACK_SPAWNS      = false,         -- ACTOR SPAWNED lines (needed by the "Encounters" achievements); enable last
    FEATURE_DELAY_MS  = 15000,
    PERSISTENT_FILE   = true,          -- also append to ludodex.log
    FILE_NAME         = "ludodex.log",
    DISCOVERY_FILE    = "ludodex-discovery.txt",
    POLL_MS           = 5000,          -- day / points polling interval
    SPAWN_WARMUP_S    = 20,            -- ignore actor spawns this long after a world load (initial level population)
    SPAWN_COOLDOWN_S  = 2,             -- do not log the same class more than once in this window
    DEDUPE_S          = 2,             -- do not log the same hooked-call line twice within this window
    MAX_HOOKS         = 40,

    -- Blueprint classes whose functions are scanned (names as they appear in /Game/main/<Class>.<Class>_C)
    CLASSES = { mainGamemode_C = true, mainPlayer_C = true, saveSlot_C = true, GameInst_C = true,
                lib_C = true, save_main_C = true },

    -- Which discovered functions get hooked: lowercase Lua patterns matched against the function name
    HOOK_GROUPS = {
        { label = "GAME ACHIEVEMENT", patterns = { "chiev" } },  -- matches mainGamemode_C:addAchievementPopup
        { label = "GAME ADVANCEMENT", patterns = { "dvancement", "^pradvanc" } },
        -- appels de progression (lib_C / save_main_C) : journalises mais JAMAIS comptes comme succes
        { label = "ACHIEVEMENT CALL", patterns = { "^progressachievement$" } },
        { label = "GAME DAY",         patterns = { "^newday$", "^nextday$", "^daychange", "^startday$", "^endday$" } },
    },
    -- ...except functions that look like getters / per-frame checks
    EXCLUDE_PREFIXES = { "get", "is", "has", "can", "check", "update", "tick", "set", "find", "calc", "achievementobjects" },

    -- numeric properties of the game mode polled for day / points (first one that exists wins)
    DAY_PROPS    = { "daysPassed", "day", "Day", "dayNumber", "days", "currentDay", "Days" },
    POINTS_PROPS = { "points", "Points", "credits", "money" },
    POINTS_MILESTONES = { 100, 500, 1000, 5000, 10000, 50000, 100000 },

    -- spawned actor classes containing one of these (lowercase) fragments are never logged
    SPAWN_IGNORE = { "light", "decal", "particle", "fx", "audio", "sound", "trigger", "hitbox", "volume",
                     "camera", "widget", "hud", "marker", "spawner", "bp_sky", "skysphere", "fog", "wind",
                     "emitter", "niagara", "trace", "debris", "gib", "blood", "splash", "ripple", "shell" },
}

local function now() return os.time() end

local function base_dir()
    local la = os.getenv("LOCALAPPDATA")
    if la and la ~= "" then return la .. "/VotV/" end
    return ""
end

local function append_file(name, text)
    local f = io.open(base_dir() .. name, "a")
    if f then f:write(text); f:close() end
end

local function emit(line)
    print(line .. "\n")
    if CFG.PERSISTENT_FILE then pcall(append_file, CFG.FILE_NAME, line .. "\n") end
end

-- champs du struct "Data" de mainGamemode_C:addAchievementPopup(Data: Struct, Type: Int)
local ACH_FIELDS = {}
local TEST_MODE = false   -- vrai pendant F7 : la ligne devient TEST ACHIEVEMENT (jamais comptee)

local function load_ach_fields()
    if #ACH_FIELDS > 0 then return end
    local fn = StaticFindObject("/Game/main/mainGamemode.mainGamemode_C:addAchievementPopup")
    if not fn or not fn:IsValid() then return end
    pcall(function()
        fn:ForEachProperty(function(p)
            if p:GetFName():ToString() == "Data" then
                p:GetStruct():ForEachProperty(function(f)
                    ACH_FIELDS[#ACH_FIELDS + 1] = { name = f:GetFName():ToString(), ty = f:GetClass():GetFName():ToString() }
                end)
            end
        end)
    end)
end

local function scalar(v)
    local t = type(v)
    if t == "string" or t == "number" or t == "boolean" then return tostring(v) end
    local ok, s = pcall(function() return v:ToString() end)
    if ok and type(s) == "string" then return s end
    return "?"
end

local function describe(p)
    local ok, v = pcall(function() return p:get() end)
    if not ok then return "?" end
    local t = type(v)
    if t == "string" or t == "number" or t == "boolean" then return tostring(v) end
    -- struct Data : lecture des champs connus
    if #ACH_FIELDS > 0 then
        local okf, first = pcall(function() return v[ACH_FIELDS[1].name] end)
        if okf and first ~= nil then
            local parts = {}
            for _, f in ipairs(ACH_FIELDS) do
                local okv, fv = pcall(function() return v[f.name] end)
                parts[#parts + 1] = f.name .. "=" .. (okv and scalar(fv) or "?")
            end
            return "{" .. table.concat(parts, "; ") .. "}"
        end
    end
    local ok2, s = pcall(function() return v:ToString() end)
    if ok2 and type(s) == "string" then return s end
    local ok3, n = pcall(function() return v:GetFullName() end)
    if ok3 and type(n) == "string" then return n end
    return "?"
end

local function short(n) return (n:gsub("_%d+_%x+$", "")) end

-- ligne : "<name> | <displayName> | progress=x/y | type=n"
-- GAME ACHIEVEMENT seulement si le succès est complet, sinon GAME ACHIEVEMENT PROGRESS
local function format_achievement(p_data, p_type)
    local f = {}
    local ok, v = pcall(function() return p_data:get() end)
    if ok and v then
        for _, fld in ipairs(ACH_FIELDS) do
            local okv, fv = pcall(function() return v[fld.name] end)
            f[short(fld.name)] = okv and scalar(fv) or "?"
        end
    end
    local typ = "?"
    if p_type then
        local okt, tv = pcall(function() return p_type:get() end)
        if okt then typ = scalar(tv) end
    end
    local prog, target = tonumber(f.progress), tonumber(f.progressTarget)
    local complete = not (target and target > 0 and prog and prog < target)
    local label = complete and "GAME ACHIEVEMENT" or "GAME ACHIEVEMENT PROGRESS"
    return label, ("%s | %s | progress=%s/%s | type=%s"):format(
        f.name or "?", f.displayName or "?", f.progress or "?", f.progressTarget or "?", typ)
end

local function fname_str(x)
    if x == nil then return "?" end
    local t = type(x)
    if t == "string" or t == "number" or t == "boolean" then return tostring(x) end
    local tries = {
        function() return x:ToString() end,
        function() return x:get():ToString() end,
        function() return tostring(x:get()) end,
    }
    for _, f in ipairs(tries) do
        local ok, s = pcall(f)
        if ok and type(s) == "string" and s ~= "" then return s end
    end
    return "?"
end

local function read_array(obj, name)
    local ok, arr = pcall(function() return obj[name] end)
    if not ok or arr == nil then return nil end
    local okc, cnt = pcall(function() return #arr end)
    if not okc or not cnt then return nil end
    local out = {}
    for i = 1, math.min(cnt, 400) do
        local oke, e = pcall(function() return arr[i] end)
        out[#out + 1] = oke and fname_str(e) or "?"
    end
    return out
end

-- ---------------------------------------------------------------- state
local world_ready_at = 0
local last_world_log = 0
local discovered = false
local last_day = nil
local points_done = {}
local recent_lines = {}
local spawn_seen = {}
local last_ach_sig = nil

-- ---------------------------------------------------------------- world load marker + delayed discovery
local started = false
local function on_world_ready()
    local t = now()
    world_ready_at = t
    if t - last_world_log > 10 then
        last_world_log = t
        emit("WORLD LOADED: x1")
    end
    if not started then
        started = true
        ExecuteWithDelay(CFG.FEATURE_DELAY_MS, function()
            ExecuteInGameThread(function() pcall(start_features) end)
        end)
    end
end

-- ---------------------------------------------------------------- Blueprint function discovery
function discover_and_hook()
    local lines = { "# Ludodex Logger discovery - " .. os.date("%Y-%m-%d %H:%M:%S") }
    local hooks = 0
    local seen = {}
    local ach_objs = {}
    ForEachUObject(function(obj)
        local ok, full = pcall(function() return obj:GetFullName() end)
        if not ok or type(full) ~= "string" then return end
        if #ach_objs < 300 and full:lower():find("chiev") then ach_objs[#ach_objs + 1] = full end
        local path = full:match("^Function (/Game/main/[^%s]+)$")
        if not path or seen[path] then return end
        local class, fname = path:match("%.([%w_]+):([%w_]+)$")
        if not class or not CFG.CLASSES[class] then return end
        seen[path] = true
        local lname = fname:lower()
        local label = nil
        for _, g in ipairs(CFG.HOOK_GROUPS) do
            for _, pat in ipairs(g.patterns) do
                if lname:find(pat) then label = g.label end
            end
        end
        if label then
            for _, pre in ipairs(CFG.EXCLUDE_PREFIXES) do
                if lname:sub(1, #pre) == pre then label = nil end
            end
        end
        local mark = ""
        if label and hooks < CFG.MAX_HOOKS then
            local hook_ok = pcall(function()
                RegisterHook(path, function(self, ...)
                    local args = { ... }
                    local line
                    if fname == "addAchievementPopup" then
                        local lbl, text = format_achievement(args[1], args[2])
                        if TEST_MODE then lbl = "TEST ACHIEVEMENT" end
                        line = lbl .. ": " .. text
                    else
                        local parts = {}
                        for _, p in ipairs(args) do parts[#parts + 1] = describe(p) end
                        line = label .. ": " .. table.concat(parts, ", ")
                    end
                    line = line .. " | fn=" .. class .. ":" .. fname
                    local t = now()
                    if recent_lines[line] and t - recent_lines[line] < CFG.DEDUPE_S then return end
                    recent_lines[line] = t
                    emit(line)
                end)
            end)
            if hook_ok then hooks = hooks + 1; mark = "  <== HOOKED as " .. label end
        end
        lines[#lines + 1] = class .. ":" .. fname .. mark
    end)

    -- numeric properties of the game mode (helps to set DAY_PROPS / POINTS_PROPS)
    local gm = FindFirstOf("mainGamemode_C")
    if gm and gm:IsValid() then
        lines[#lines + 1] = "# properties of mainGamemode_C"
        pcall(function()
            gm:GetClass():ForEachProperty(function(prop)
                local n = prop:GetFName():ToString()
                local ty = prop:GetClass():GetFName():ToString()
                lines[#lines + 1] = "prop " .. n .. " (" .. ty .. ")"
            end)
        end)
    end
    -- v1.2: scalar properties WITH current values (to find the day / points fields)
    local function dump_scalars(obj, title)
        lines[#lines + 1] = "# " .. title
        pcall(function()
            obj:GetClass():ForEachProperty(function(prop)
                local n = prop:GetFName():ToString()
                local ty = prop:GetClass():GetFName():ToString()
                if ty == "IntProperty" or ty == "FloatProperty" or ty == "Int64Property"
                    or ty == "BoolProperty" or ty == "StrProperty" or ty == "ByteProperty" then
                    local okv, v = pcall(function() return obj[n] end)
                    lines[#lines + 1] = "val " .. n .. " (" .. ty .. ") = " .. tostring(okv and v or "?")
                end
            end)
        end)
    end
    if gm and gm:IsValid() then
        local okS, ss = pcall(function() return gm.saveSlot end)
        if okS and ss and ss:IsValid() then dump_scalars(ss, "scalars of mainGamemode_C.saveSlot") end
        local okG, gi = pcall(function() return gm.GameInstance end)
        if okG and gi and gi:IsValid() then dump_scalars(gi, "scalars of GameInstance") end
        -- fields of the Time struct
        pcall(function()
            gm:GetClass():ForEachProperty(function(prop)
                if prop:GetFName():ToString() == "Time" then
                    lines[#lines + 1] = "# fields of mainGamemode_C.Time"
                    local st = prop:GetStruct()
                    st:ForEachProperty(function(f)
                        local fn = f:GetFName():ToString()
                        local okv, v = pcall(function() return gm.Time[fn] end)
                        lines[#lines + 1] = "time." .. fn .. " (" .. f:GetClass():GetFName():ToString() .. ") = " .. tostring(okv and v or "?")
                    end)
                end
            end)
        end)
    end
    -- v1.5/v1.6 : succes deja presents dans le jeu (rien n'est debloque)
    local function decode_row(v)
        local f = {}
        for _, fld in ipairs(ACH_FIELDS) do
            local okv, fv = pcall(function() return v[fld.name] end)
            f[short(fld.name)] = okv and scalar(fv) or "?"
        end
        local txt = ("name=%s | displayName=%s | target=%s | award=%s | desc=%s"):format(
            f.name or "?", f.displayName or "?", f.progressTarget or "?", f.award or "?", f.desc or "?")
        return (txt:gsub("[\r\n]+", " "))
    end

    -- liste complete des succes : DataTable /Game/main/datatables/list_achievements
    local function dump_ach_table()
        local dt = StaticFindObject("/Game/main/datatables/list_achievements.list_achievements")
        if not dt or not dt:IsValid() then lines[#lines + 1] = "ach-table: introuvable" return end
        local n = 0
        local okA, errA = pcall(function()
            dt.RowMap:ForEach(function(k, v)
                n = n + 1
                local key = scalar(k:get())
                local okr, row = pcall(function() return v:get() end)
                lines[#lines + 1] = "ach-row " .. key .. " | " .. ((okr and row) and decode_row(row) or "?")
            end)
        end)
        lines[#lines + 1] = "ach-table A(RowMap): rows=" .. n .. " ok=" .. tostring(okA)
            .. (okA and "" or (" err=" .. tostring(errA):match("^[^\n]*")))
        if n > 0 then return end
        local libo = StaticFindObject("/Script/Engine.Default__DataTableFunctionLibrary")
        local out = {}
        local okB, r1, r2 = pcall(function() return libo:GetDataTableRowNames(dt, out) end)
        local cands = { out, r1, r2 }
        local m = 0
        for ci = 1, 3 do
            local c = cands[ci]
            if m == 0 and (type(c) == "table" or type(c) == "userdata") then
                local okc, cnt = pcall(function() return #c end)
                if okc and cnt and cnt > 0 then
                    for i = 1, cnt do
                        local oke, nm = pcall(function() return c[i] end)
                        if i == 1 then lines[#lines + 1] = "ach-table B first-elem type=" .. type(nm) .. " str=" .. tostring(nm) end
                        lines[#lines + 1] = "ach-row-name " .. (oke and fname_str(nm) or "?")
                        m = m + 1
                    end
                end
            end
        end
        lines[#lines + 1] = "ach-table B(GetDataTableRowNames): names=" .. m .. " ok=" .. tostring(okB)
    end
    pcall(dump_ach_table)

    for _, o in ipairs(ach_objs) do lines[#lines + 1] = "ach-object " .. o end
    local function dump_ach_props(obj, title, all)
        if not obj then return end
        local okv, valid = pcall(function() return obj:IsValid() end)
        if not okv or not valid then return end
        lines[#lines + 1] = "# achievement-like props of " .. title
        pcall(function()
            obj:GetClass():ForEachProperty(function(prop)
                local n = prop:GetFName():ToString()
                local ln = n:lower()
                local match = ln:find("chiev") or ln:find("award") or ln:find("trophy") or ln:find("^ach")
                if match or all then
                    local ty = prop:GetClass():GetFName():ToString()
                    local head = "ach-prop " .. title .. "." .. n .. " (" .. ty .. ")"
                    local okp, val = pcall(function() return obj[n] end)
                    if match and ty == "ArrayProperty" and okp and val ~= nil then
                        local okc, cnt = pcall(function() return #val end)
                        lines[#lines + 1] = head .. " count=" .. tostring(okc and cnt or "?")
                        for i = 1, math.min(okc and cnt or 0, 400) do
                            local oke, e = pcall(function() return val[i] end)
                            lines[#lines + 1] = "ach-entry " .. n .. "[" .. i .. "] = "
                                .. (oke and describe({ get = function() return e end }) or "?")
                        end
                    elseif okp and val ~= nil and (ty == "IntProperty" or ty == "BoolProperty" or ty == "StrProperty" or ty == "FloatProperty") then
                        lines[#lines + 1] = head .. " = " .. scalar(val)
                    else
                        lines[#lines + 1] = head
                    end
                end
            end)
        end)
    end
    if gm and gm:IsValid() then
        local okS, ss = pcall(function() return gm.saveSlot end)
        local okG, gi = pcall(function() return gm.GameInstance end)
        local okM, sm = pcall(function() return gm.save_main end)
        dump_ach_props(gm, "mainGamemode")
        dump_ach_props(okS and ss or nil, "saveSlot")
        dump_ach_props(okG and gi or nil, "GameInstance")
        dump_ach_props(okM and sm or nil, "save_main", true)   -- toutes les props : c'est la qu'est progressAchievement
    end
    dump_ach_props(FindFirstOf("mainPlayer_C"), "mainPlayer")
    pcall(append_file, CFG.DISCOVERY_FILE, table.concat(lines, "\n") .. "\n")
    emit("LUDODEX LOGGER READY: hooks=" .. hooks .. " | functions=" .. (#lines - 1))
end

-- ---------------------------------------------------------------- actor spawns
local function ignored(lname)
    for _, frag in ipairs(CFG.SPAWN_IGNORE) do
        if lname:find(frag, 1, true) then return true end
    end
    return false
end

local spawn_queue = {}

local function register_spawn_tracking()
    -- The callback only stores the object; it is inspected later from the game thread (poll),
    -- because objects are still under construction when the notification fires.
    NotifyOnNewObject("/Script/Engine.Actor", function(obj)
        if #spawn_queue < 300 then spawn_queue[#spawn_queue + 1] = obj end
    end)
end

local function process_spawns()
    local queue = spawn_queue
    spawn_queue = {}
    local t = now()
    if t - world_ready_at < CFG.SPAWN_WARMUP_S then return end
    for _, obj in ipairs(queue) do
        local ok, cname = pcall(function()
            if not obj:IsValid() then return nil end
            return obj:GetClass():GetFName():ToString()
        end)
        if ok and type(cname) == "string" and cname:sub(-2) == "_C" then
            local lname = cname:lower()
            if not ignored(lname) and not (spawn_seen[cname] and t - spawn_seen[cname] < CFG.SPAWN_COOLDOWN_S) then
                spawn_seen[cname] = t
                emit("ACTOR SPAWNED: " .. cname)
            end
        end
    end
end

-- ---------------------------------------------------------------- day / points polling
local function read_number(gm, names)
    -- search the game mode, then its saveSlot and its Time struct
    local holders = { gm }
    local ok1, ss = pcall(function() return gm.saveSlot end)
    if ok1 and ss then holders[#holders + 1] = ss end
    local ok2, tm = pcall(function() return gm.Time end)
    if ok2 and tm then holders[#holders + 1] = tm end
    for _, obj in ipairs(holders) do
        for _, n in ipairs(names) do
            local ok, v = pcall(function() return obj[n] end)
            if ok and type(v) == "number" then return v end
        end
    end
    return nil
end

local function poll()
    if CFG.TRACK_SPAWNS then process_spawns() end
    if not CFG.ENABLE_POLLING then return end
    local gm = FindFirstOf("mainGamemode_C")
    if not gm or not gm:IsValid() then return end
    local day = read_number(gm, CFG.DAY_PROPS)
    if day then
        day = math.floor(day)
        if last_day == nil or day > last_day then
            emit("DAY REACHED: " .. day)
            last_day = day
        end
    end
    -- etat des succes stocke dans save_main (source independante du popup)
    pcall(function()
        local sm = gm.save_main
        if not sm or not sm:IsValid() then return end
        local names = read_array(sm, "achievementsNames")
        local comp = read_array(sm, "achievementsCompleted")
        local prog = read_array(sm, "achievements")
        if not names and not comp and not prog then return end
        local a = table.concat(names or {}, ",")
        local b = table.concat(prog or {}, ",")
        local c = table.concat(comp or {}, ",")
        local sig = a .. "|" .. b .. "|" .. c
        if sig ~= last_ach_sig then
            last_ach_sig = sig
            emit(("ACHIEVEMENT STATE: names=%s | progress=%s | completed=%s"):format(a, b, c))
        end
    end)
    local pts = read_number(gm, CFG.POINTS_PROPS)
    if pts then
        for _, m in ipairs(CFG.POINTS_MILESTONES) do
            if pts >= m and not points_done[m] then
                points_done[m] = true
                emit("POINTS MILESTONE: " .. m)
            end
        end
    end
end

function start_features()
    emit("LUDODEX LOGGER STARTING: polling=" .. tostring(CFG.ENABLE_POLLING) .. " | discovery=" .. tostring(CFG.ENABLE_DISCOVERY)
        .. " | spawns=" .. tostring(CFG.TRACK_SPAWNS))
    if CFG.TRACK_SPAWNS then pcall(register_spawn_tracking) end
    if CFG.ENABLE_POLLING or CFG.TRACK_SPAWNS then
        LoopAsync(CFG.POLL_MS, function()
            ExecuteInGameThread(function() pcall(poll) end)
            return false
        end)
    end
    pcall(load_ach_fields)
    if CFG.ENABLE_DISCOVERY and not discovered then
        discovered = true
        pcall(discover_and_hook)
    else
        emit("LUDODEX LOGGER READY: hooks=0 | functions=0")
    end
end

-- ---------------------------------------------------------------- entry point
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(self)
    pcall(on_world_ready)
end)
emit("LUDODEX LOGGER LOADED: x1")


-- ---------------------------------------------------------------- debug keys
local ACH_TEST = "Super burger finder"

-- F6 : log les champs du struct Data
RegisterKeyBind(Key.F6, function()
    ExecuteInGameThread(function()
        load_ach_fields()
        for _, f in ipairs(ACH_FIELDS) do emit(("ACHFIELD: %s (%s)"):format(f.name, f.ty)) end
        if #ACH_FIELDS == 0 then emit("ACHFIELD: aucun champ lu") end
    end)
end)

-- F7 : appelle addAchievementPopup avec une table construite depuis les champs de Data
RegisterKeyBind(Key.F7, function()
    ExecuteInGameThread(function()
        local gm = FindFirstOf("mainGamemode_C")
        if not gm or not gm:IsValid() then emit("ACHTEST: pas de gamemode") return end
        load_ach_fields()
        local data = {}
        for _, f in ipairs(ACH_FIELDS) do
            if f.ty == "StrProperty" then data[f.name] = ACH_TEST
            elseif f.ty == "TextProperty" then data[f.name] = FText(ACH_TEST)
            elseif f.ty == "NameProperty" then data[f.name] = FName(ACH_TEST)
            elseif f.ty == "IntProperty" or f.ty == "FloatProperty" then data[f.name] = 0
            elseif f.ty == "BoolProperty" then data[f.name] = false end
        end
        TEST_MODE = true
        local ok, err = pcall(function() gm:addAchievementPopup(data, 0) end)
        TEST_MODE = false
        emit(("ACHTEST: ok=%s err=%s"):format(tostring(ok), tostring(err)))
    end)
end)
