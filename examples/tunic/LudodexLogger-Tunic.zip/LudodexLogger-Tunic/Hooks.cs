using System;
using System.Reflection;
using HarmonyLib;
using Il2CppInterop.Runtime.InteropTypes;
using UnityEngine;

namespace LudodexLogger;

// Hooks Harmony résolus par nom au runtime : un nom introuvable est compté
// dans "missing" sans faire planter le plugin.
internal static class Hooks
{
    internal static int Hooked;
    internal static int Missing;
    internal static bool InventorySetIntHooked;
    internal static bool ItemPickupHooked;

    private static bool _pickupPropsDumped;

    internal static void Install(Harmony h)
    {
        Hook(h, "PlayerCharacter", "Die", nameof(DiePost), postfix: true);
        Hook(h, "PermanentStateByPosition", "onKilled", nameof(KilledPre), postfix: false);
        Hook(h, "TrinketWell", "TossedInCoin", nameof(WishPost), postfix: true);

        InventorySetIntHooked = HookSaveInt(h);
        ItemPickupHooked = HookItemPickup(h);
    }

    private static void Hook(Harmony h, string typeName, string method, string hookName, bool postfix)
    {
        try
        {
            var type = LudodexPoller.FindType(typeName);
            var original = type == null ? null : AccessTools.Method(type, method);
            if (original == null)
            {
                Missing++;
                LudodexLoggerPlugin.Log.LogWarning($"Hook missing: {typeName}.{method}");
                return;
            }

            var hook = new HarmonyMethod(typeof(Hooks).GetMethod(hookName,
                BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public));

            if (postfix) h.Patch(original, postfix: hook);
            else h.Patch(original, prefix: hook);

            Hooked++;
        }
        catch (Exception e)
        {
            Missing++;
            LudodexLoggerPlugin.Log.LogWarning($"Hook failed: {typeName}.{method}: {e.Message}");
        }
    }

    // ------------------------------------------------------------ SaveFile.SetInt

    private static bool HookSaveInt(Harmony h)
    {
        try
        {
            var type = LudodexPoller.FindType("SaveFile");
            var original = type == null ? null : AccessTools.Method(type, "SetInt", new[] { typeof(string), typeof(int) });
            if (original == null)
            {
                Missing++;
                LudodexLoggerPlugin.Log.LogWarning("Hook missing: SaveFile.SetInt(string, int)");
                return false;
            }

            h.Patch(original,
                prefix: new HarmonyMethod(typeof(Hooks).GetMethod(nameof(SaveIntPre), BindingFlags.Static | BindingFlags.NonPublic)),
                postfix: new HarmonyMethod(typeof(Hooks).GetMethod(nameof(SaveIntPost), BindingFlags.Static | BindingFlags.NonPublic)));
            Hooked++;
            return true;
        }
        catch (Exception e)
        {
            Missing++;
            LudodexLoggerPlugin.Log.LogWarning($"Hook failed: SaveFile.SetInt(string, int): {e.Message}");
            return false;
        }
    }

    private static void SaveIntPre(string k, int v, out int __state)
    {
        __state = 0;
        try
        {
            if (string.IsNullOrEmpty(k) || !k.StartsWith("inventory quantity ", StringComparison.Ordinal)) return;
            var saveFile = LudodexPoller.FindType("SaveFile");
            var getter = saveFile == null ? null : AccessTools.Method(saveFile, "GetInt", new[] { typeof(string) });
            if (getter != null) __state = Convert.ToInt32(getter.Invoke(null, new object[] { k }));
        }
        catch { }
    }

    private static void SaveIntPost(string k, int v, int __state)
    {
        try
        {
            if (string.IsNullOrEmpty(k) || !k.StartsWith("inventory quantity ", StringComparison.Ordinal)) return;
            LudodexPoller.LogInventoryMutation(k.Substring("inventory quantity ".Length), __state, v);
        }
        catch { /* never interfere with gameplay */ }
    }

    // ------------------------------------------------------------------ divers

    private static void DiePost() => LudodexPoller.Emit("PLAYER DIED: x1");

    private static void WishPost() => LudodexPoller.Emit("WISH MADE: x1");

    private static void KilledPre(object __instance)
    {
        try
        {
            var name = (__instance as Il2CppObjectBase)?.TryCast<Component>()?.gameObject?.name ?? "";

            if (name.IndexOf("grass", StringComparison.OrdinalIgnoreCase) >= 0)
                LudodexPoller.Emit("GRASS CUT: x1");
            else if (LudodexLoggerPlugin.Discovery.Value)
                LudodexPoller.Emit($"BREAKABLE KILLED: {name}");
        }
        catch { /* ne jamais casser le gameplay */ }
    }

    // ------------------------------------------------------- ItemPickup.onGetIt

    private static bool HookItemPickup(Harmony h)
    {
        try
        {
            var type = LudodexPoller.FindType("ItemPickup");
            var original = type == null ? null : AccessTools.Method(type, "onGetIt");

            if (original == null)
            {
                LudodexLoggerPlugin.Log.LogWarning("Hook missing: ItemPickup.onGetIt");
                Missing++;
                return false;
            }

            var postfix = new HarmonyMethod(typeof(Hooks).GetMethod(
                nameof(ItemPickupPost), BindingFlags.Static | BindingFlags.NonPublic));

            h.Patch(original, postfix: postfix);
            Hooked++;
            LudodexLoggerPlugin.Log.LogInfo("Hook installed: ItemPickup.onGetIt");
            return true;
        }
        catch (Exception e)
        {
            Missing++;
            LudodexLoggerPlugin.Log.LogWarning($"Hook failed: ItemPickup.onGetIt: {e}");
            return false;
        }
    }

    private static void ItemPickupPost(object __instance)
    {
        try
        {
            if (__instance == null) return;

            // Avec Il2CppInterop, les champs du jeu sont exposés comme des PROPRIÉTÉS.
            const BindingFlags all = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            var type = __instance.GetType();

            var prop = type.GetProperty("itemToGive", all);
            if (prop == null)
            {
                if (!_pickupPropsDumped)
                {
                    _pickupPropsDumped = true;
                    foreach (var p in type.GetProperties(all))
                        LudodexLoggerPlugin.Log.LogInfo($"ItemPickup property: {p.Name} ({p.PropertyType.Name})");
                }
                LudodexLoggerPlugin.Log.LogWarning("ItemPickup: property itemToGive not found");
                return;
            }

            var item = prop.GetValue(__instance);
            if (item == null)
            {
                LudodexLoggerPlugin.Log.LogWarning("ItemPickup: itemToGive is null");
                return;
            }

            var itemName = item.GetType().GetProperty("name", all | BindingFlags.FlattenHierarchy)
                ?.GetValue(item)?.ToString();

            if (string.IsNullOrWhiteSpace(itemName))
                itemName = item.ToString();

            LudodexLoggerPlugin.Log.LogInfo($"ItemPickup detected: {itemName}");

            // Simple fallback : n'émet que si le polling du SaveFile ne fonctionne pas.
            LudodexPoller.LogPickedUpItem(itemName);
        }
        catch (Exception e)
        {
            LudodexLoggerPlugin.Log.LogWarning($"ItemPickup logging failed: {e}");
        }
    }
}