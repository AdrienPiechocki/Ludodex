# LudodexLogger-TUNIC

A BepInEx 6 IL2CPP plugin for **TUNIC** (GOG version, launched through Heroic
and Proton).

It observes game-state transitions and writes them to a log file that can be
consumed by Ludodex’s **Achievements** module:

```text
/home/adrien/Jeux/Heroic/TUNIC/BepInEx/ludodex.log
```

The plugin does not modify gameplay: it only reads save data and the active
scene.

## Requirements

- TUNIC installed from GOG through Heroic.
- Proton (tested with `proton-cachyos-slr`).
- BepInEx **6.0.0-pre.1**, **Unity IL2CPP win-x64** variant.
- .NET SDK 8 or newer.

Important: use the **Windows x64** build even on Linux, because TUNIC runs
inside a Proton prefix.

```text
BepInEx-Unity.IL2CPP-win-x64-6.0.0-pre.1.zip
```

## Installing BepInEx

1. Open the game directory:

```bash
cd /home/adrien/Jeux/Heroic/TUNIC
```

2. Extract **the entire contents** of the BepInEx archive into the root of the
game directory:

```bash
unzip -o ~/Downloads/BepInEx-Unity.IL2CPP-win-x64-6.0.0-pre.1.zip -d .
```

3. Verify that these files and folders are present in the game root:

```bash
ls -la | grep -E 'winhttp|doorstop|dotnet|BepInEx'
```

You should see:

```text
BepInEx/
dotnet/
winhttp.dll
doorstop_config.ini
.doorstop_version
```

4. In Heroic, add the following environment variable to TUNIC:

| Variable | Value |
|---|---|
| `WINEDLLOVERRIDES` | `winhttp=n,b` |

5. Launch TUNIC once through Heroic, wait for the title screen, then quit the
game.

The first launch may take a while: BepInEx generates the IL2CPP interop
assemblies in `BepInEx/interop/`.

6. Verify that BepInEx loaded:

```bash
head -50 /home/adrien/Jeux/Heroic/TUNIC/BepInEx/LogOutput.log
```

## Building the plugin

From the project root:

```bash
cd ~/Projets/Ludodex/examples/tunic/LudodexLogger-Tunic
dotnet build -c Release
```

The plugin is built here:

```text
bin/Release/net472/LudodexLogger.dll
```

## Installing the plugin

```bash
mkdir -p /home/adrien/Jeux/Heroic/TUNIC/BepInEx/plugins/LudodexLogger

cp bin/Release/net472/LudodexLogger.dll \
   /home/adrien/Jeux/Heroic/TUNIC/BepInEx/plugins/LudodexLogger/
```

## Verifying the installation

Launch TUNIC through Heroic, then check that the plugin loaded:

```bash
grep -i ludodex /home/adrien/Jeux/Heroic/TUNIC/BepInEx/LogOutput.log
```

You should see:

```text
LudodexLogger-TUNIC loaded.
```

Then start a new game and watch the log:

```bash
tail -f /home/adrien/Jeux/Heroic/TUNIC/BepInEx/ludodex.log
```

After picking up the stick and sword, you should see:

```text
LUDODEX LOGGER READY: hooked=poller missing=pending
SCENE ENTERED: ...
ITEM ACQUIRED: Stick
ITEM ACQUIRED: Sword
```

## Log format

The plugin writes only when a value changes.

```text
ITEM ACQUIRED: <Item>
INVENTORY COUNT: <Item> | n=<count>
CHEST OPENED: <chestID>
FLAG SET: <saveKey>
FLAG CHANGED: <saveKey> | <old> -> <new>
PLAYER DIED: x1
FAIRY FREED: <1-20>
SECRET TREASURE FOUND: <1-12>
MANUAL PAGE FOUND: <0-27> | n=<count>/28
GRASS CUT: x1
WISH MADE: x1
MONEYBANK COUNT: n=<count>
GUN ACQUIRED BEFORE SWORD
SCENE ENTERED: <sceneName>
LUDODEX LOGGER READY: hooked=poller missing=pending
```

Examples:

```text
ITEM ACQUIRED: Stick
ITEM ACQUIRED: Sword
INVENTORY COUNT: Torch | n=1
CHEST OPENED: 32
FLAG SET: Has Ever Died
SCENE ENTERED: Overworld
```

## Config

`BepInEx/config/com.adrienpiechocki.ludodexlogger.tunic.cfg` :

- `Discovery` (false) : logge aussi chaque breakable détruit (`BREAKABLE KILLED: <nom>`).
- `FloatsAndStrings` (false) : logge floatStore/stringStore (bruyant).

The logger emits `ITEM ACQUIRED: <Item>` whenever an inventory quantity increases.
Unique treasures emit `SECRET TREASURE FOUND` only on their first acquisition.

## Using with Ludodex

In Ludodex, configure the **Achievements** module with:

```text
/home/adrien/Jeux/Heroic/TUNIC/BepInEx/ludodex.log
```

Then load:

```text
examples/tunic/tunic-achievements.yaml
```

Ludodex rules use the events above to unlock achievements as you play.

## Disabling

To disable BepInEx without deleting its files, remove this environment
variable from the game settings in Heroic:

```text
WINEDLLOVERRIDES=winhttp=n,b
```

Alternatively, rename the Doorstop proxy:

```bash
cd /home/adrien/Jeux/Heroic/TUNIC
mv winhttp.dll winhttp.dll.disabled
```

To disable only LudodexLogger:

```bash
rm -rf /home/adrien/Jeux/Heroic/TUNIC/BepInEx/plugins/LudodexLogger
```

## Troubleshooting

### BepInEx does not start

Check that these files exist in the game root:

```bash
ls -la /home/adrien/Jeux/Heroic/TUNIC | grep -E 'winhttp|doorstop|dotnet'
```

If `dotnet/` is missing, the BepInEx archive was not fully extracted.
Re-extract the complete `Unity.IL2CPP-win-x64` archive.

### No `LogOutput.log` file

Check the Heroic environment variable:

```text
WINEDLLOVERRIDES=winhttp=n,b
```

It is required so that Proton loads BepInEx’s `winhttp.dll` instead of Wine’s
system version.

### The plugin does not appear in the logs

Verify that the DLL is here:

```bash
ls -la /home/adrien/Jeux/Heroic/TUNIC/BepInEx/plugins/LudodexLogger/
```

Then relaunch the game and search for:

```bash
grep -i ludodex /home/adrien/Jeux/Heroic/TUNIC/BepInEx/LogOutput.log
```

### `ludodex.log` does not appear

The plugin writes to:

```bash
/home/adrien/Jeux/Heroic/TUNIC/BepInEx/ludodex.log
```

You must start a game and trigger at least one state change: pick up an item,
open a chest, enter a scene, die, and so on.
