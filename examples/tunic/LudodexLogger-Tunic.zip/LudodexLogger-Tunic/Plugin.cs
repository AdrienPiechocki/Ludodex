using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;

namespace LudodexLogger;

[BepInPlugin(PluginGuid, PluginName, PluginVersion)]
public sealed class LudodexLoggerPlugin : BasePlugin
{
    public const string PluginGuid = "com.adrienpiechocki.ludodexlogger.tunic";
    public const string PluginName = "LudodexLogger-TUNIC";
    public const string PluginVersion = "1.2.0";

    internal static ManualLogSource Log;
    internal static ConfigEntry<bool> Discovery;
    internal static ConfigEntry<bool> LogFloatsAndStrings;

    public override void Load()
    {
        Log = base.Log;

        Discovery = Config.Bind("Logging", "Discovery", false,
            "Log extra diagnostic lines (every breakable killed, raw key changes) to find unknown keys.");
        LogFloatsAndStrings = Config.Bind("Logging", "FloatsAndStrings", false,
            "Log floatStore/stringStore changes (noisy: playtime etc.).");

        Hooks.Install(new Harmony(PluginGuid));

        if (AddComponent<LudodexPoller>() == null)
        {
            Log.LogError("Could not add LudodexPoller component.");
            return;
        }

        Log.LogInfo($"{PluginName} loaded (hooked={Hooks.Hooked} missing={Hooks.Missing}).");
    }
}
