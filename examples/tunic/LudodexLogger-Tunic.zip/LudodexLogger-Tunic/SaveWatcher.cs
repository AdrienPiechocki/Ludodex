using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using HarmonyLib;
using Il2CppInterop.Runtime.InteropTypes;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace LudodexLogger;

public sealed class LudodexPoller : MonoBehaviour
{
    private const float PollIntervalSeconds = 0.25f;
    private const int TotalPages = 28;
    private const long AcquireDedupeTicks = 15_000_000; // 1,5 s

    private static readonly object Sync = new();
    private static readonly Dictionary<string, Type> TypeCache = new();
    private static readonly Dictionary<string, long> LastAcquired = new(StringComparer.Ordinal);
    private static StreamWriter _writer;

    private static Type _saveFileType;
    private static object _saveFileInstance;
    private static readonly Dictionary<Type, PropertyInfo[]> KeyValProps = new();

    /// <summary>true quand la lecture de SaveFile.intStore renvoie des clés.</summary>
    internal static bool PollingWorks;

    private Dictionary<string, int> _int = new(StringComparer.Ordinal);
    private Dictionary<string, float> _float = new(StringComparer.Ordinal);
    private Dictionary<string, string> _string = new(StringComparer.Ordinal);

    private IntPtr _intPtr;
    private bool _needBaseline = true;
    private bool _diagLogged;
    private float _nextPoll;
    private string _lastScene;
    private readonly HashSet<string> _warned = new();

    private static string LogPath =>
    Path.GetFullPath(Path.Combine(Application.dataPath, "..", "BepInEx", "ludodex.log"));

    // ---------------------------------------------------------------- infra

    internal static Type FindType(string name)
    {
        if (TypeCache.TryGetValue(name, out var cached)) return cached;

        Type found = null;
        foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
        {
            var n = asm.GetName().Name;
            if (n != "Assembly-CSharp" && !n.StartsWith("Il2Cpp", StringComparison.Ordinal)) continue;

            try
            {
                foreach (var t in asm.GetTypes())
                {
                    if (t.Name == name && t.Namespace == null) { found = t; break; }
                }
            }
            catch { }

            if (found != null) break;
        }

        TypeCache[name] = found;
        return found;
    }

    internal static void Emit(string line)
    {
        lock (Sync)
        {
            try { _writer?.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} {line}"); }
            catch (Exception e) { LudodexLoggerPlugin.Log.LogError($"Log write failed: {e.Message}"); }
        }
    }

    /// <summary>Vide complètement le fichier de log en cours de route.</summary>
    internal static void ClearLog()
    {
        lock (Sync)
        {
            try
            {
                _writer?.Dispose();
                _writer = null;

                File.WriteAllText(LogPath, string.Empty);

                _writer = new StreamWriter(LogPath, append: true) { AutoFlush = true };
            }
            catch (Exception e)
            {
                LudodexLoggerPlugin.Log.LogError($"Failed to clear log file: {e.Message}");
            }
        }
    }

    private void Start()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);

            // Optionnel : si vous souhaitez vider le log à chaque lancement complet du jeu
            if (File.Exists(LogPath)) File.WriteAllText(LogPath, string.Empty);

            lock (Sync) { _writer = new StreamWriter(LogPath, append: true) { AutoFlush = true }; }

            Emit("SESSION START");
            Emit($"LUDODEX LOGGER READY: hooked={Hooks.Hooked} missing={Hooks.Missing}");
            LudodexLoggerPlugin.Log.LogInfo($"Logging to {LogPath}");
        }
        catch (Exception e)
        {
            LudodexLoggerPlugin.Log.LogError($"Failed to open log file: {e}");
        }
    }

    private void OnDestroy()
    {
        lock (Sync) { _writer?.Dispose(); _writer = null; }
    }

    private void Update()
    {
        if (_writer == null || Time.unscaledTime < _nextPoll) return;
        _nextPoll = Time.unscaledTime + PollIntervalSeconds;

        try { Poll(); }
        catch (Exception e) { LudodexLoggerPlugin.Log.LogError($"Poll failed: {e}"); }
    }

    // ----------------------------------------------------------------- poll

    private void Poll()
    {
        var scene = SceneManager.GetActiveScene();
        var sceneName = scene.IsValid() ? scene.name : "";

        if (!string.IsNullOrEmpty(sceneName) && sceneName != _lastScene)
        {
            _lastScene = sceneName;

            // Exemple : vider le log lorsqu'on entre dans une scène spécifique marquant le début d'une partie
            // if (sceneName == "NomDeLaSceneDeJeu")
            // {
            //     ClearLog();
            // }

            Emit($"SCENE ENTERED: {sceneName}");
        }

        // Sur l'écran titre le SaveFile peut être celui d'une autre sauvegarde :
        // on se recale silencieusement au premier poll en jeu.
        if (sceneName == "TitleScreen" || sceneName == "")
        {
            _needBaseline = true;
            return;
        }

        if (!ResolveSaveFile()) return;

        var intDict = GetStore("intStore");
        if (intDict == null) return;

        if (intDict.Pointer != _intPtr)
        {
            _intPtr = intDict.Pointer;
            _needBaseline = true;
        }

        var cur = new Dictionary<string, int>(_int.Count + 16, StringComparer.Ordinal);
        ReadIntStore(intDict, cur);

        // Store illisible ou vide : on ne prend pas de baseline vide
        if (cur.Count == 0)
        {
            PollingWorks = false;
            if (!_diagLogged)
            {
                _diagLogged = true;
                LudodexLoggerPlugin.Log.LogWarning(
                    $"intStore unreadable/empty. Runtime type: {intDict.GetType().FullName}");
            }
            return;
        }

        PollingWorks = true;

        if (_needBaseline)
            LudodexLoggerPlugin.Log.LogInfo($"Baseline intStore: {cur.Count} keys");

        if (!_needBaseline && cur.Count < _int.Count / 2) _needBaseline = true; // autre sauvegarde chargée

        if (_needBaseline)
        {
            _int = cur;
            _needBaseline = false;
            PollOptionalStores(baseline: true);
            return;
        }

        var changes = new List<(string key, int prev, int value)>();
        foreach (var kv in cur)
        {
            _int.TryGetValue(kv.Key, out var prev);
            if (prev != kv.Value) changes.Add((kv.Key, prev, kv.Value));
        }

        _int = cur;

        foreach (var c in changes) HandleInt(c.key, c.prev, c.value);

        PollOptionalStores(baseline: false);
    }

    private void HandleInt(string key, int prev, int value)
    {
        if (key == "playtime") return;

        if (key.StartsWith("chest open ", StringComparison.Ordinal))
        {
            if (prev == 0 && value != 0) Emit($"CHEST OPENED: {key.Substring(11)}");
            return;
        }

        if (key.StartsWith("inventory quantity ", StringComparison.Ordinal))
        {
            HandleInventory(key.Substring(19), prev, value);
            return;
        }

        if (key.StartsWith("SV_Fairy_", StringComparison.Ordinal) &&
            key.EndsWith("_Opened", StringComparison.Ordinal) && prev == 0 && value != 0)
        {
            var rest = key.Substring(9);
            var id = rest.Split('_')[0];
            Emit($"FAIRY FREED: {id}");
            Emit($"FLAG SET: {key}");
            return;
        }

        if (key.StartsWith("unlocked page ", StringComparison.Ordinal))
        {
            if (prev == 0 && value == 1)
            {
                Emit($"MANUAL PAGE FOUND: {key.Substring(14)}");
                Emit($"MANUAL PAGE FOUND: n={CountPages()}/{TotalPages}");
            }
            return;
        }

        if (prev == 0 && value != 0) Emit($"FLAG SET: {key}");
        else Emit($"FLAG CHANGED: {key} | {prev} -> {value}");
    }

    // ------------------------------------------------------------ inventaire

    private void HandleInventory(string item, int prev, int value)
    {
        if (item.StartsWith("Money", StringComparison.Ordinal) || item == "[realmoney]") return;

        if (value > prev && value > 0)
            LogInventoryAcquisition(item, prev, value);

        Emit($"INVENTORY COUNT: {item} | n={value}");

        if (item.StartsWith("Piggybank", StringComparison.Ordinal))
            Emit($"MONEYBANK COUNT: n={value}");
    }

    internal static void LogInventoryMutation(string item, int prev, int value)
    {
        if (string.IsNullOrEmpty(item)) return;
        if (item.StartsWith("Money", StringComparison.Ordinal) || item == "[realmoney]") return;
        if (value > prev && value > 0) LogInventoryAcquisition(item, prev, value);
    }

    internal static void LogPickedUpItem(string itemName)
    {
        if (string.IsNullOrWhiteSpace(itemName)) return;
        if (itemName.StartsWith("Money", StringComparison.Ordinal) || itemName == "[realmoney]") return;
        if (PollingWorks) return;

        LogInventoryAcquisition(itemName, 0, 1);
    }

    private static bool MarkAcquired(string item)
    {
        var now = DateTime.UtcNow.Ticks;
        lock (Sync)
        {
            if (LastAcquired.TryGetValue(item, out var last) && now - last < AcquireDedupeTicks)
                return false;
            LastAcquired[item] = now;
            return true;
        }
    }

    private static void LogInventoryAcquisition(string item, int prev, int value)
    {
        if (!MarkAcquired(item)) return;

        Emit($"ITEM ACQUIRED: {item}");

        if (prev == 0 && item.StartsWith("GoldenTrophy_", StringComparison.Ordinal))
            Emit($"SECRET TREASURE FOUND: {item.Substring("GoldenTrophy_".Length)}");

        if (prev == 0 && item == "Shotgun")
        {
            try
            {
                var saveFile = FindType("SaveFile");
                var getter = saveFile == null ? null : AccessTools.Method(saveFile, "GetInt", new[] { typeof(string) });
                if (getter != null)
                {
                    var sword = Convert.ToInt32(getter.Invoke(null, new object[] { "inventory quantity Sword" }));
                    var progression = Convert.ToInt32(getter.Invoke(null, new object[] { "inventory quantity Sword Progression" }));
                    if (sword == 0 && progression == 0) Emit("GUN ACQUIRED BEFORE SWORD");
                }
            }
            catch { }
        }
    }

    private int CountPages()
    {
        var n = 0;
        for (var i = 0; i < TotalPages; i++)
            if (_int.TryGetValue($"unlocked page {i}", out var v) && v == 1) n++;
            return n;
    }

    private void PollOptionalStores(bool baseline)
    {
        if (!LudodexLoggerPlugin.LogFloatsAndStrings.Value) return;

        var fd = GetStore("floatStore");
        if (fd != null)
        {
            var cur = new Dictionary<string, float>(StringComparer.Ordinal);
            ReadFloatStore(fd, cur);
            if (!baseline)
                foreach (var kv in cur)
                    if (_float.TryGetValue(kv.Key, out var p) && Math.Abs(p - kv.Value) > 0.0001f)
                        Emit($"FLOAT CHANGED: {kv.Key} | {p} -> {kv.Value}");
            _float = cur;
        }

        var sd = GetStore("stringStore");
        if (sd != null)
        {
            var cur = new Dictionary<string, string>(StringComparer.Ordinal);
            ReadStringStore(sd, cur);
            if (!baseline)
                foreach (var kv in cur)
                {
                    if (!_string.TryGetValue(kv.Key, out var p)) { if (kv.Value != "") Emit($"STRING SET: {kv.Key} | {kv.Value}"); }
                    else if (p != kv.Value) Emit($"STRING CHANGED: {kv.Key} | {p} -> {kv.Value}");
                }
                _string = cur;
        }
    }

    // ------------------------------------------------------------- réflexion

    private bool ResolveSaveFile()
    {
        _saveFileType ??= FindType("SaveFile");
        if (_saveFileType == null) { Warn("SaveFile type"); return false; }

        const BindingFlags all = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

        _saveFileInstance = _saveFileType.GetField("instance", all)?.GetValue(null)
        ?? _saveFileType.GetProperty("instance", all)?.GetValue(null);

        return true;
    }

    private Il2CppObjectBase GetStore(string name)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

        var field = _saveFileType.GetField(name, any);
        if (field != null)
            return field.GetValue(field.IsStatic ? null : _saveFileInstance) as Il2CppObjectBase;

        var prop = _saveFileType.GetProperty(name, any);
        if (prop != null)
            return prop.GetValue(_saveFileInstance) as Il2CppObjectBase;

        Warn($"SaveFile.{name}");
        return null;
    }

    private static void ReadIntStore(Il2CppObjectBase dict, Dictionary<string, int> into)
    {
        try
        {
            var typed = dict.TryCast<Il2CppSystem.Collections.Generic.Dictionary<string, int>>();
            if (typed != null)
            {
                foreach (var kv in typed) into[kv.Key] = kv.Value;
                return;
            }
        }
        catch (Exception e)
        {
            LudodexLoggerPlugin.Log.LogWarning($"Typed intStore read failed: {e.Message}");
        }

        ReadStoreReflection(dict, (k, v) => into[k] = Convert.ToInt32(v));
    }

    private static void ReadFloatStore(Il2CppObjectBase dict, Dictionary<string, float> into)
    {
        try
        {
            var typed = dict.TryCast<Il2CppSystem.Collections.Generic.Dictionary<string, float>>();
            if (typed != null)
            {
                foreach (var kv in typed) into[kv.Key] = kv.Value;
                return;
            }
        }
        catch { }

        ReadStoreReflection(dict, (k, v) => into[k] = Convert.ToSingle(v));
    }

    private static void ReadStringStore(Il2CppObjectBase dict, Dictionary<string, string> into)
    {
        try
        {
            var typed = dict.TryCast<Il2CppSystem.Collections.Generic.Dictionary<string, string>>();
            if (typed != null)
            {
                foreach (var kv in typed) into[kv.Key] = kv.Value ?? "";
                return;
            }
        }
        catch { }

        ReadStoreReflection(dict, (k, v) => into[k] = v?.ToString() ?? "");
    }

    private static void ReadStoreReflection(Il2CppObjectBase dict, Action<string, object> add)
    {
        var t = dict.GetType();

        if (!KeyValProps.TryGetValue(t, out var props))
            KeyValProps[t] = props = new[] { t.GetProperty("Keys"), t.GetProperty("Values") };

        if (props[0]?.GetValue(dict) is not IEnumerable keys || props[1]?.GetValue(dict) is not IEnumerable vals)
            return;

        var ke = keys.GetEnumerator();
        var ve = vals.GetEnumerator();

        while (ke.MoveNext() && ve.MoveNext())
        {
            var k = ke.Current?.ToString();
            if (!string.IsNullOrEmpty(k)) add(k, ve.Current);
        }
    }

    private void Warn(string member)
    {
        if (_warned.Add(member))
            LudodexLoggerPlugin.Log.LogWarning($"Missing game member: {member}");
    }
}
