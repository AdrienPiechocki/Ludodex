-- Ludodex Logger (script joueur)
-- Écrit dans openmw.log (via print) des lignes lisibles par le module
-- « Achievements » de Ludodex. Format : « TAG: valeur | détails ».
-- Le timestamp [HH:MM:SS] est ajouté par OpenMW lui-même.

local core  = require('openmw.core')
local self  = require('openmw.self')
local types = require('openmw.types')

local CONFIG = {
    tick           = 0.5,    -- secondes entre deux vérifications
    logCellEntered = true,   -- une ligne « CELL ENTERED » à chaque changement de cell
    logGold        = true,   -- inclure l'or dans ITEM ACQUIRED / ITEM REMOVED
    backfillQuests = false,  -- true : logge QUEST COMPLETE pour les quêtes déjà finies au 1er lancement
}

local SKILLS = {
    'block', 'armorer', 'mediumarmor', 'heavyarmor', 'bluntweapon', 'longblade',
    'axe', 'spear', 'athletics', 'enchant', 'destruction', 'alteration',
    'illusion', 'conjuration', 'mysticism', 'restoration', 'alchemy',
    'unarmored', 'security', 'sneak', 'acrobatics', 'lightarmor',
    'shortblade', 'marksman', 'mercantile', 'speechcraft', 'handtohand',
}
local ATTRIBUTES = {
    'strength', 'intelligence', 'willpower', 'agility',
    'speed', 'endurance', 'personality', 'luck',
}

-- État persistant (sauvegardé avec la partie)
local discovered = {}

-- État volatil (re-baseliné à chaque chargement, sans rien logger)
local ready, timer
local lastCellKey, lastLevel, lastBounty, wasDead
local lastSkills, lastAttrs, lastInv, invNames, lastSpells, lastFactions
local questStage, questDone
local warned = {}

local function reset()
    ready, timer = false, 0
    lastCellKey, lastLevel, lastBounty, wasDead = nil, nil, nil, false
    lastSkills, lastAttrs, lastInv, invNames = {}, {}, {}, {}
    lastSpells, lastFactions = {}, {}
    questStage, questDone = {}, {}
end
reset()

local function log(tag, msg, extra)
    local line = tag .. ': ' .. tostring(msg)
    if extra then line = line .. ' | ' .. extra end
    print(line)
end

local function safe(name, f, ...)
    local ok, err = pcall(f, ...)
    if not ok and not warned[name] then
        warned[name] = true
        print('LUDODEX WARNING: check "' .. name .. '" failed: ' .. tostring(err))
    end
end

---------------------------------------------------------------- Cells / lieux
local function checkCell()
    local cell = self.cell
    if not cell then return end
    local name = cell.name or ''
    local key = cell.isExterior
        and ('ext:' .. tostring(cell.gridX) .. ',' .. tostring(cell.gridY))
        or ('int:' .. name)
    if key == lastCellKey then return end
    lastCellKey = key

    if CONFIG.logCellEntered and ready then
        log('CELL ENTERED', name ~= '' and name or key, cell.isExterior and 'exterior' or 'interior')
    end

    if cell.isExterior then
        if name ~= '' and not discovered['loc:' .. name] then
            discovered['loc:' .. name] = true
            log('LOCATION DISCOVERED', name)
        end
        local region = cell.region
        if region and region ~= '' and not discovered['reg:' .. region] then
            discovered['reg:' .. region] = true
            log('REGION DISCOVERED', region)
        end
    elseif name ~= '' and not discovered['int:' .. name] then
        discovered['int:' .. name] = true
        log('INTERIOR DISCOVERED', name)
    end
end

---------------------------------------------------------------- Niveau / stats
local function checkLevel()
    local lvl = types.Actor.stats.level(self).current
    if lastLevel and lvl > lastLevel then log('LEVEL UP', lvl) end
    lastLevel = lvl
end

local function checkStats()
    for _, id in ipairs(SKILLS) do
        local v = types.NPC.stats.skills[id](self).base
        local old = lastSkills[id]
        if old and v > old then log('SKILL UP', id, 'level=' .. v) end
        lastSkills[id] = v
    end
    for _, id in ipairs(ATTRIBUTES) do
        local v = types.Actor.stats.attributes[id](self).base
        local old = lastAttrs[id]
        if old and v > old then log('ATTRIBUTE UP', id, 'value=' .. v) end
        lastAttrs[id] = v
    end
end

---------------------------------------------------------------- Inventaire
local function checkInventory()
    local snap, names = {}, {}
    for _, item in ipairs(types.Actor.inventory(self):getAll()) do
        local id = item.recordId
        snap[id] = (snap[id] or 0) + item.count
        if not names[id] then
            local ok, rec = pcall(function() return item.type.record(item) end)
            names[id] = (ok and rec and rec.name and rec.name ~= '') and rec.name or id
        end
    end
    if ready then
        for id, count in pairs(snap) do
            local diff = count - (lastInv[id] or 0)
            if diff > 0 and (CONFIG.logGold or id ~= 'gold_001') then
                log('ITEM ACQUIRED', names[id], 'x' .. diff .. ' | id=' .. id)
            end
        end
        for id, old in pairs(lastInv) do
            local diff = old - (snap[id] or 0)
            if diff > 0 and (CONFIG.logGold or id ~= 'gold_001') then
                log('ITEM REMOVED', names[id] or invNames[id] or id, 'x' .. diff .. ' | id=' .. id)
            end
        end
    end
    lastInv, invNames = snap, names
end

---------------------------------------------------------------- Sorts
local function checkSpells()
    local snap = {}
    local spellType = core.magic and core.magic.SPELL_TYPE and core.magic.SPELL_TYPE.Spell
    for _, spell in pairs(types.Actor.spells(self)) do
        if spellType == nil or spell.type == spellType then
            snap[spell.id] = spell.name or spell.id
        end
    end
    if ready then
        for id, name in pairs(snap) do
            if not lastSpells[id] then log('SPELL LEARNED', name, 'id=' .. id) end
        end
    end
    lastSpells = snap
end

---------------------------------------------------------------- Factions
local function factionInfo(id, rank)
    local fname, rname = id, nil
    local ok, rec = pcall(function() return core.factions.records[id] end)
    if ok and rec then
        fname = rec.name or id
        local ok2, r = pcall(function() return rec.ranks[rank] end)
        if ok2 and r then rname = r.name end
    end
    return fname, rname
end

local function checkFactions()
    local snap = {}
    for _, id in ipairs(types.NPC.getFactions(self)) do
        snap[id] = types.NPC.getFactionRank(self, id)
    end
    if ready then
        for id, rank in pairs(snap) do
            local fname, rname = factionInfo(id, rank)
            if lastFactions[id] == nil then
                log('FACTION JOINED', fname, 'id=' .. id)
            elseif rank ~= lastFactions[id] then
                log('FACTION RANK', fname, 'rank=' .. tostring(rank) .. (rname and (' | title=' .. rname) or ''))
            end
        end
        for id in pairs(lastFactions) do
            if snap[id] == nil then
                local fname = factionInfo(id, 0)
                log('FACTION LEFT', fname, 'id=' .. id)
            end
        end
    end
    lastFactions = snap
end

---------------------------------------------------------------- Prime / mort
local function checkBounty()
    local b = types.Player.getCrimeLevel(self)
    if lastBounty ~= nil and b ~= lastBounty then
        log(b > lastBounty and 'BOUNTY INCREASED' or 'BOUNTY DECREASED', b, 'previous=' .. lastBounty)
    end
    lastBounty = b
end

local function checkDeath()
    local dead = types.Actor.isDead(self)
    if dead and not wasDead and ready then log('PLAYER DIED', 'Player') end
    wasDead = dead
end

---------------------------------------------------------------- Quêtes
local function checkQuest(id, quest, stageOverride)
    quest = quest or types.Player.quests(self)[id]
    if not quest then return end
    local stage = stageOverride or quest.stage
    if ready then
        if questStage[id] == nil and (stage or 0) > 0 then log('QUEST STARTED', id) end
        if stage ~= questStage[id] then log('QUEST UPDATE', id, 'stage=' .. tostring(stage)) end
        if quest.finished and not questDone[id] then log('QUEST COMPLETE', id) end
    elseif CONFIG.backfillQuests and quest.finished then
        log('QUEST COMPLETE', id, 'backfill')
    end
    questStage[id] = stage
    questDone[id] = questDone[id] or quest.finished or false
end

local function pollQuests()
    for id, quest in pairs(types.Player.quests(self)) do
        checkQuest(id, quest)
    end
end

---------------------------------------------------------------- Boucle
local function onUpdate(dt)
    timer = timer + dt
    if timer < CONFIG.tick then return end
    timer = 0

    safe('cell',      checkCell)
    safe('level',     checkLevel)
    safe('stats',     checkStats)
    safe('inventory', checkInventory)
    safe('spells',    checkSpells)
    safe('factions',  checkFactions)
    safe('bounty',    checkBounty)
    safe('death',     checkDeath)
    safe('quests',    pollQuests)

    ready = true
end

local function onInit()
    reset()
    print('LUDODEX LOGGER STARTED')
end

local function onLoad(data)
    reset()
    discovered = (data and data.discovered) or {}
    print('GAME LOADED: Ludodex Logger')
end

local function onSave()
    return { discovered = discovered }
end

-- Appelé par OpenMW 0.49+ à chaque changement de journal
local function onQuestUpdate(questId, stage)
    safe('quest', checkQuest, questId, nil, stage)
end

-- Événement envoyé par OpenMW à chaque changement de mode d'interface
local function onUiModeChanged(data)
    if not ready or not data or data.newMode == data.oldMode then return end
    local mode, arg = data.newMode, data.arg
    local who
    if arg then
        local ok, rec = pcall(function() return arg.type.record(arg) end)
        who = (ok and rec and rec.name and rec.name ~= '') and rec.name or arg.recordId
    end
    if mode == 'Dialogue' then
        log('NPC TALKED', who or 'unknown')
    elseif mode == 'Barter' then
        log('BARTER OPENED', who or 'unknown')
    elseif mode == 'Training' then
        log('TRAINING OPENED', who or 'unknown')
    elseif mode == 'Travel' then
        log('TRAVEL SERVICE OPENED', who or 'unknown')
    elseif mode == 'SpellBuying' then
        log('SPELL SERVICE OPENED', who or 'unknown')
    elseif mode == 'Book' then
        log('BOOK READ', who or 'unknown', arg and ('id=' .. tostring(arg.recordId)) or nil)
    elseif mode == 'Scroll' then
        log('SCROLL READ', who or 'unknown', arg and ('id=' .. tostring(arg.recordId)) or nil)
    elseif mode == 'Rest' then
        log('REST', 'started')
    elseif mode == 'Alchemy' then
        log('ALCHEMY OPENED', 'Alchemy')
    elseif mode == 'Enchanting' then
        log('ENCHANTING OPENED', 'Enchanting')
    elseif mode == 'Repair' then
        log('REPAIR OPENED', 'Repair')
    end
end

return {
    engineHandlers = {
        onInit        = onInit,
        onLoad        = onLoad,
        onSave        = onSave,
        onUpdate      = onUpdate,
        onQuestUpdate = onQuestUpdate,
    },
    eventHandlers = {
        UiModeChanged = onUiModeChanged,
    },
}
