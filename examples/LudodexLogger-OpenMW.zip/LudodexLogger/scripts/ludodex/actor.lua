-- Ludodex Logger (script d'acteur, attaché aux PNJ et créatures)
-- Logge : ENEMY ENCOUNTER, NPC KILLED / CREATURE KILLED (tué par le joueur)
-- et NPC DIED / CREATURE DIED (mort sans lien avec le joueur).

local self  = require('openmw.self')
local types = require('openmw.types')
local I     = require('openmw.interfaces')

local TICK = 0.25
local timer = 0
local seenAlive = false          -- évite de logger les cadavres déjà présents au chargement
local reported = false
local encounterActive = false
local fightedPlayer = false
local lastAttackerWasPlayer = nil

local function actorName()
    local ok, rec = pcall(function() return self.type.record(self) end)
    if ok and rec and rec.name and rec.name ~= '' then return rec.name end
    return self.recordId
end

-- Mémorise qui a porté le dernier coup (OpenMW 0.49+ : interface Combat)
if I.Combat and I.Combat.addOnHitHandler then
    I.Combat.addOnHitHandler(function(attack)
        if attack and attack.attacker and attack.successful ~= false then
            lastAttackerWasPlayer = (attack.attacker.type == types.Player)
        end
        -- on ne retourne rien : le coup n'est pas annulé
    end)
end

local function isFightingPlayer()
    if not (I.AI and I.AI.getActivePackage) then return false end
    local pkg = I.AI.getActivePackage()
    return pkg ~= nil and pkg.type == 'Combat'
        and pkg.target ~= nil and pkg.target.type == types.Player
end

local function onUpdate(dt)
    if reported then return end
    timer = timer + dt
    if timer < TICK then return end
    timer = 0

    if types.Actor.isDead(self) then
        if not seenAlive then reported = true return end
        reported = true
        local byPlayer
        if lastAttackerWasPlayer ~= nil then
            byPlayer = lastAttackerWasPlayer
        else
            byPlayer = fightedPlayer   -- sort / dégâts indirects : on se base sur le combat en cours
        end
        local kind = (self.type == types.NPC) and 'NPC' or 'CREATURE'
        print(kind .. (byPlayer and ' KILLED: ' or ' DIED: ') .. actorName() .. ' | id=' .. self.recordId)
        return
    end

    seenAlive = true

    local ok, fighting = pcall(isFightingPlayer)
    fighting = ok and fighting
    if fighting and not encounterActive then
        encounterActive = true
        fightedPlayer = true
        print('ENEMY ENCOUNTER: ' .. actorName() .. ' | id=' .. self.recordId)
    elseif not fighting then
        encounterActive = false
    end
end

return {
    engineHandlers = {
        onUpdate = onUpdate,
    },
}
